Welcome to Character Pack #1! This quality art pack was created by professional artist Hermann Hillmann and made available to you free for non-commercial use. If you looked around you know that it is impossible to find sprite and other game art of this quality for free! 

This pack may not be posted on any other site or included in any other collection of graphics -free or otherwise- included nor distributed in any fashion other than as stated here. Copyright is maintained by Hermann Hillmann with exclusive distribution rights assigned to Visual Basic Explorer. If you wish to use this product in a commercial product you may contact me for registration information. This would enable you to get advance notice of any future paid packages and allow you to purchase them at a discounted price. The availability of future Character Packs is dependent upon the popularity of this package and on whether or not the conditions mentioned herein are respected. Frankly, we had the opportunity to distribute this art through CD sales in stores but decided to give this a try instead. If their is enough interest Hermann may produce additional low cost art packs as time allows. 

Please note: Hermann has stated that he is not interested in producing free art for your game projects, or art in exchange for money in the event that you sell your game. He asked that he not be contacted for this purpose as he does not have the time to do that type of work. If you are interested in payed artwork, then you can contact him and find out what his current schedule is like. Serious inquiries only. 

What is the Character Pack?

The Character Pack is a collection of high-quality rendered game art created by professional artist Hermann Hillmann. Character Pack #1 contains animation sequences for four different sprites. Each sprite has over 900 frames of animation including walking, firing weapons, sword hacking, exploding and more. In addition each character contains nine portraits which are larger sized views of the sprite which you can use creatively to enhance your game. This set also includes a bonus pack with close to 900 tiles as well as some background art and a few other odd items. 

Does it have everything I need?

While it is certainly possible to create a full game with this pack that is not its aim. This pack answers the frequent cry for good quality game sprites. You may be able to supplement this art with some of your own or from other free collections. I plan on adding new items if they become available. Some of these may be free and some for sale as it is unlikely that artists will give away their best art -they have to eat too. If the demand is great enough they may decide that they can make good money selling these smaller sprite packs and I may be able to arrange some additional sprite and object collections -let's see how it goes. 

Burt Abreu
http://www.vbexplorer.com

